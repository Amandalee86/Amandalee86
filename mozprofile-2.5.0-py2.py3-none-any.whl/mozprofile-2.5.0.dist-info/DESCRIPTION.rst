see https://firefox-source-docs.mozilla.org/mozbase/index.html


